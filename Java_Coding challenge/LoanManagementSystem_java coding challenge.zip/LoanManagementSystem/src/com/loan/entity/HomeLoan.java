package com.loan.entity;

public class HomeLoan extends Loan {
	private String propertyAddress;
	private int propertyValue;
	
	//default constructor
	public HomeLoan() {}

	//Constructor
	public HomeLoan(int loanId, Customer customer, double principalAmount, double inerestRate, int longTerm,
			String loanType, String loanStatus, int propertyValue, String propertyAddress) {
		super(loanId, customer, principalAmount, inerestRate, longTerm, "HomeLoan", loanStatus);
		this.propertyAddress = propertyAddress;
		this.propertyValue = propertyValue;
	}

	//getters and setters
	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public int getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(int propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	@Override
	public String toString() {
		return super.toString() + ", HomeLoan [propertyAddress=" + propertyAddress + ", propertyValue=" + propertyValue + "]";

	
	}
	
	
	

}

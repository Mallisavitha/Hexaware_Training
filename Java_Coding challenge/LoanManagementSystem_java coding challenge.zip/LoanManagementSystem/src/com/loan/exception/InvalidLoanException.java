package com.loan.exception;

public class InvalidLoanException extends RuntimeException {
	 public InvalidLoanException(String message) {
	        super(message);
	    }
	

}

package com.loan.entity;

public abstract class Loan {
	protected int loanId;
	protected Customer customer;
	protected double principalAmount;
	protected double inerestRate;
	protected int longTerm;
	protected String loanType;
	protected String loanStatus;
	
	//default constructor
	public Loan() {}

	//constructors
	public Loan(int loanId, Customer customer, double principalAmount, double inerestRate, int longTerm,
			String loanType, String loanStatus) {
		this.loanId = loanId;
		this.customer = customer;
		this.principalAmount = principalAmount;
		this.inerestRate = inerestRate;
		this.longTerm = longTerm;
		this.loanType = loanType;
		this.loanStatus = loanStatus;
	}

	//getters and setters
	public int getLoanId() {
		return loanId;
	}

	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(double principalAmount) {
		this.principalAmount = principalAmount;
	}

	public double getInerestRate() {
		return inerestRate;
	}

	public void setInerestRate(double inerestRate) {
		this.inerestRate = inerestRate;
	}

	public int getLongTerm() {
		return longTerm;
	}

	public void setLongTerm(int longTerm) {
		this.longTerm = longTerm;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public String getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(String loanStatus) {
		this.loanStatus = loanStatus;
	}

	//Print all attributes
	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", customer=" + customer + ", principalAmount=" + principalAmount
				+ ", inerestRate=" + inerestRate + ", longTerm=" + longTerm + ", loanType=" + loanType + ", loanStatus="
				+ loanStatus + "]";
	}
	
	
	

}

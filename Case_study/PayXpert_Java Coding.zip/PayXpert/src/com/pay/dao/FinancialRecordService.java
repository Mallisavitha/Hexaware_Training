package com.pay.dao;

import com.pay.entity.FinancialRecord;
import com.pay.exception.FinancialRecordException;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

public class FinancialRecordService implements IFinancialRecordService {
	private Connection conn;
	public FinancialRecordService(Connection conn) {
		this.conn=conn;
	}
	
	@Override
	public boolean addFinancialRecord(FinancialRecord record) {
		// TODO Auto-generated method stub
		 try {
	            String sql = "INSERT INTO FinancialRecord VALUES (?, ?, ?, ?, ?, ?)";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, record.getRecordID());
	            ps.setInt(2, record.getEmployeeID());
	            ps.setDate(3, Date.valueOf(record.getRecordDate()));
	            ps.setString(4, record.getDescription());
	            ps.setDouble(5, record.getAmount());
	            ps.setString(6, record.getRecordType());

	            int rows = ps.executeUpdate();
	            if (rows == 0) {
	                throw new FinancialRecordException("Failed to add financial record for Employee ID: " + record.getEmployeeID());
	            }
	            return true;
	        } 
		 catch (SQLException e) {
			 throw new FinancialRecordException("Error adding record: " + e.getMessage());
	        }
	}
	
	@Override
	public FinancialRecord getFinancialRecordById(int recordId) {
		// TODO Auto-generated method stub
		try {
            String sql = "SELECT * FROM FinancialRecord WHERE RecordID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, recordId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return extract(rs);
            else throw new FinancialRecordException("Record ID "+recordId+" not found");
        } 
		catch (SQLException e) {
			throw new FinancialRecordException("Error: " + e.getMessage());
        }
	}
	
	@Override
	public List<FinancialRecord> getFinancialRecordsForEmployee(int employeeId) {
		// TODO Auto-generated method stub
		 List<FinancialRecord> list = new ArrayList<>();
	        try {
	            String sql = "SELECT * FROM FinancialRecord WHERE EmployeeID=?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, employeeId);
	            ResultSet rs = ps.executeQuery();
	            while (rs.next()) list.add(extract(rs));
	        } 
	        catch (SQLException e) {
	        	throw new FinancialRecordException("Error: " + e.getMessage());
	        }
	        return list;
	}
	
	@Override
	public List<FinancialRecord> getFinancialRecordsForDate(LocalDate date) {
		// TODO Auto-generated method stub
		List<FinancialRecord> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM FinancialRecord WHERE RecordDate=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(date));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));
        } 
        catch (SQLException e) {
        	throw new FinancialRecordException("Error: " + e.getMessage());
        }
        return list;
	}

	 private FinancialRecord extract(ResultSet rs) throws SQLException {
	        return new FinancialRecord(
	            rs.getInt("RecordID"),
	            rs.getInt("EmployeeID"),
	            rs.getDate("RecordDate").toLocalDate(),
	            rs.getString("Description"),
	            rs.getDouble("Amount"),
	            rs.getString("RecordType")
	        );
	    }
	

}

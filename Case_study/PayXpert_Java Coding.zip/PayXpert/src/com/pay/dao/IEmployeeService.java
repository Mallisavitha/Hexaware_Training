package com.pay.dao;

import com.pay.entity.*;
import java.util.List;

public interface IEmployeeService {
	Employee getEmployeeId(int employeeId);
	List<Employee> getAllEmployees();
	boolean addEmployee(Employee employee);
	boolean updateEmployee(Employee employee);
	boolean removeEmployee(int employeeId);

}

package com.pay.dao;

import com.pay.entity.Payroll;
import com.pay.exception.PayrollGenerationException;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

public class PayrollService implements IPayrollService{
	private Connection conn;
	public PayrollService(Connection conn) {
		this.conn=conn;
	}
	
	@Override
	public boolean generatePayroll(Payroll payroll) {
		// TODO Auyto-generated method stub
		try {
			
            //	NetSalary Calculation
			double netSalary=payroll.getBasicSalary()+payroll.getOvertimePay()-payroll.getDeductions();
			payroll.setNetSalary(netSalary);
			
			String sql = "INSERT INTO Payroll VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, payroll.getPayrollID());
            ps.setInt(2, payroll.getEmployeeID());
            ps.setDate(3, Date.valueOf(payroll.getPayPeriodStartDate()));
            ps.setDate(4, Date.valueOf(payroll.getPayPeriodEndDate()));
            ps.setDouble(5, payroll.getBasicSalary());
            ps.setDouble(6, payroll.getOvertimePay());
            ps.setDouble(7, payroll.getDeductions());
            ps.setDouble(8, payroll.getNetSalary());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new PayrollGenerationException("Payroll generation failed for Employee ID: " + payroll.getEmployeeID());
            }
            return true;
		}
		catch(SQLException e) {
			throw new PayrollGenerationException("Error generating payroll: "+e.getMessage());
		}
	}
	
	@Override
	public Payroll getPayrollById(int payrollId) {
		// TODO Auto-generated method stub
		 try {
	            String sql = "SELECT * FROM Payroll WHERE PayrollID=?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, payrollId);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) return extract(rs);
	            else throw new PayrollGenerationException("Payroll ID "+payrollId+" not found");
	        } 
		 catch (SQLException e) {
	            throw new PayrollGenerationException("Error: " + e.getMessage());
	        }

	}
	
	@Override
	public List<Payroll> getPayrollsForEmployee(int employeeId) {
		// TODO Auto-generated method stub
		List<Payroll> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Payroll WHERE EmployeeID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));
        } 
        catch (SQLException e) {
            throw new PayrollGenerationException("Error: " + e.getMessage());
        }
		return list;
	}
	
	@Override
	public List<Payroll> getPayrollsForPeriod(LocalDate start, LocalDate end) {
		// TODO Auto-generated method stub
		List<Payroll> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Payroll WHERE PayPeriodsStartDate >= ? AND PayPeriodsEndDate <= ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, Date.valueOf(start));
            ps.setDate(2, Date.valueOf(end));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));
        } 
        catch (SQLException e) {
            throw new PayrollGenerationException("Error: " + e.getMessage());
        }
        return list;
	}
	
	 private Payroll extract(ResultSet rs) throws SQLException {
	        return new Payroll(
	            rs.getInt("PayrollID"),
	            rs.getInt("EmployeeID"),
	            rs.getDate("PayPeriodsStartDate").toLocalDate(),
	            rs.getDate("PayPeriodsEndDate").toLocalDate(),
	            rs.getDouble("BasicSalary"),
	            rs.getDouble("OvertimePay"),
	            rs.getDouble("Deductions"),
	            rs.getDouble("NetSalary")
	        );
	    }

}

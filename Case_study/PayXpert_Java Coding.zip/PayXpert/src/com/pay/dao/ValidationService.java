package com.pay.dao;

import java.util.regex.Pattern;

public class ValidationService {
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
        );

        public static boolean isValidEmail(String email) {
            return EMAIL_PATTERN.matcher(email).matches();
        }

        public static boolean isValidPhone(String phone) {
            return phone != null && phone.matches("\\d{10}");
        }

	
}

package com.pay.dao;

import com.pay.entity.Employee;
import com.pay.exception.EmployeeNotFoundException;
import com.pay.exception.InvalidInputException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeService implements IEmployeeService {
	private Connection conn;
	public EmployeeService (Connection conn) {
		this.conn=conn;
	}

	@Override
	public Employee getEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		 try {
	            String sql = "SELECT * FROM Employee WHERE EmployeeID = ?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setInt(1, employeeId);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) return extract(rs);
	            else throw new EmployeeNotFoundException("Employee ID "+employeeId+" not found.");
	        } 
		 catch (SQLException e) {
	            throw new EmployeeNotFoundException("Error: " + e.getMessage());
		 }
	}

	

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		 List<Employee> list = new ArrayList<>();
	        try {
	            String sql = "SELECT * FROM Employee";
	            Statement st = conn.createStatement();
	            ResultSet rs = st.executeQuery(sql);
	            while (rs.next()) list.add(extract(rs));
	        } 
	        catch (SQLException e) {
	            throw new EmployeeNotFoundException("Error: " + e.getMessage());
	        }
	        return list;
	}
	
	public void validateEmployee(Employee employee) {
	    if (employee.getEmployeeId() <= 0)
	        throw new InvalidInputException("Employee ID must be positive.");
	    if (employee.getFirstName() == null || employee.getFirstName().isEmpty())
	        throw new InvalidInputException("First name cannot be empty.");
	    if (employee.getLastName() == null || employee.getLastName().trim().isEmpty())
	        throw new InvalidInputException("Last name cannot be empty.");
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		try {
            String sql = "INSERT INTO Employee VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employee.getEmployeeId());
            ps.setString(2, employee.getFirstName());
            ps.setString(3, employee.getLastName());
            ps.setDate(4, Date.valueOf(employee.getDateOfBirth()));
            ps.setString(5, employee.getGender());
            ps.setString(6, employee.getEmail());
            ps.setString(7, employee.getPhoneNumber());
            ps.setString(8, employee.getAddress());
            ps.setString(9, employee.getPosition());
            ps.setDate(10, Date.valueOf(employee.getJoiningDate()));
            if (employee.getTerminationDate() != null)
                ps.setDate(11, Date.valueOf(employee.getTerminationDate()));
            else
                ps.setNull(11, Types.DATE);

            return ps.executeUpdate() > 0;
        } 
		catch (SQLException ex) {
            throw new EmployeeNotFoundException("Error adding employee: " + ex.getMessage());
        }
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		 try {
	            String sql = "UPDATE Employee SET FirstName=?, LastName=?, DateOfBirth=?, Gender=?, Email=?, PhoneNumber=?, Address=?, Position=?, JoiningDate=?, TerminationDate=? WHERE EmployeeID=?";
	            PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setString(1, employee.getFirstName());
	            ps.setString(2, employee.getLastName());
	            ps.setDate(3, Date.valueOf(employee.getDateOfBirth()));
	            ps.setString(4, employee.getGender());
	            ps.setString(5, employee.getEmail());
	            ps.setString(6, employee.getPhoneNumber());
	            ps.setString(7, employee.getAddress());
	            ps.setString(8, employee.getPosition());
	            ps.setDate(9, Date.valueOf(employee.getJoiningDate()));
	            if (employee.getTerminationDate() != null)
	                ps.setDate(10, Date.valueOf(employee.getTerminationDate()));
	            else
	                ps.setNull(10, Types.DATE);
	            ps.setInt(11, employee.getEmployeeId());

	            return ps.executeUpdate() > 0;
	        } 
		 catch (SQLException ex) {
	            throw new EmployeeNotFoundException("Error updating employee: " + ex.getMessage());
	        }
	}

	@Override
	public boolean removeEmployee(int employeeId) {
		// TODO Auto-generated method stub
		try {
            String sql = "DELETE FROM Employee WHERE EmployeeID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            if (ps.executeUpdate() == 0) {
                throw new EmployeeNotFoundException("No employee found with ID: " + employeeId);
            }
            return true;
        } 
		catch (SQLException ex) {
            throw new EmployeeNotFoundException("Error deleting employee: " + ex.getMessage());
        }

	}
	
	private Employee extract(ResultSet rs) throws SQLException {
        return new Employee(
                rs.getInt("EmployeeID"),
                rs.getString("FirstName"),
                rs.getString("LastName"),
                rs.getDate("DateOfBirth").toLocalDate(),
                rs.getString("Gender"),
                rs.getString("Email"),
                rs.getString("PhoneNumber"),
                rs.getString("Address"),
                rs.getString("Position"),
                rs.getDate("JoiningDate").toLocalDate(),
                rs.getDate("TerminationDate") != null ? rs.getDate("TerminationDate").toLocalDate() : null
        );
    }

}

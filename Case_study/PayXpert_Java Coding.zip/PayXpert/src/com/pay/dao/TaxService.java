package com.pay.dao;

import com.pay.entity.Tax;
import com.pay.exception.TaxCalculationException;

import java.sql.*;
import java.util.*;

public class TaxService implements ITaxService {
	private Connection conn;
	public TaxService(Connection conn) {
		this.conn=conn;
	}
	
	@Override
	public boolean calculateTax(Tax tax) {
		// TODO Auto-generated method stub
		try {
			// From payroll net salary
            double income = tax.getTaxableIncome(); 
            double taxAmount = 0;

            // Slab-based tax calculation
            if (income <= 500000) {
                taxAmount = income * 0.10;
            } 
            else if (income>500000 && income <= 1000000) {
                taxAmount = income * 0.20;
            } 
            else {
                taxAmount = income * 0.30;
            }

         // Update Tax object with calculated tax
            tax.setTaxAmount(taxAmount); 

            String sql = "INSERT INTO Tax VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, tax.getTaxID());
            ps.setInt(2, tax.getEmployeeID());
            ps.setInt(3, tax.getTaxYear());
            ps.setDouble(4, tax.getTaxableIncome());
            ps.setDouble(5, tax.getTaxAmount());

            int rows = ps.executeUpdate();
            if (rows == 0) {
                throw new TaxCalculationException("Failed to insert tax for Employee ID: " + tax.getEmployeeID());
            }

            return true;

        } 
		catch (SQLException e) {
			throw new TaxCalculationException("Error calculating tax: " + e.getMessage());
        }

	}
	
	@Override
	public Tax getTaxById(int taxId) {
		// TODO Auto-generated method stub
		try {
            String sql = "SELECT * FROM Tax WHERE TaxID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, taxId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return extract(rs);
            else throw new TaxCalculationException("Tax ID "+taxId+" not found");
        } 
		catch (SQLException e) {
			throw new TaxCalculationException("Error: " + e.getMessage());
        }

	}
	
	@Override
	public List<Tax> getTaxesForEmployee(int employeeId) {
		// TODO Auto-generated method stub
		List<Tax> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Tax WHERE EmployeeID=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));
        } catch (SQLException e) {
        	throw new TaxCalculationException("Error: " + e.getMessage());
        }
        return list;
	}
	
	@Override
	public List<Tax> getTaxesForYear(int taxYear) {
		// TODO Auto-generated method stub
		List<Tax> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Tax WHERE TaxYear=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, taxYear);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(extract(rs));
        } 
        catch (SQLException e) {
        	throw new TaxCalculationException("Error: " + e.getMessage());
        }
        return list;
	}
	
	private Tax extract(ResultSet rs) throws SQLException {
        return new Tax(
            rs.getInt("TaxID"),
            rs.getInt("EmployeeID"),
            rs.getInt("TaxYear"),
            rs.getDouble("TaxableIncome"),
            rs.getDouble("TaxAmount")
        );
    }

}

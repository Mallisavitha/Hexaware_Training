package com.pay.dao;

import com.pay.entity.Tax;
import java.util.List;

public interface ITaxService {
	boolean calculateTax(Tax tax);
	Tax getTaxById(int taxId);
	List<Tax> getTaxesForEmployee(int employeeId);
	List<Tax> getTaxesForYear(int taxYear);

}

package com.pay.dao;

import com.pay.entity.Payroll;
import java.time.LocalDate;
import java.util.List;

public interface IPayrollService {
	boolean generatePayroll(Payroll payroll);
	Payroll getPayrollById(int payrollId);
	List<Payroll> getPayrollsForEmployee(int employeeId);
	List<Payroll> getPayrollsForPeriod(LocalDate start,LocalDate end);

}

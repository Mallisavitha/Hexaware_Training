package com.pay.exception;

public class FinancialRecordException extends RuntimeException {
	public FinancialRecordException(String message) {
		super(message);
	}

}

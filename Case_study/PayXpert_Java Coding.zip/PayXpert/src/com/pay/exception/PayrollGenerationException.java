package com.pay.exception;

public class PayrollGenerationException extends RuntimeException {
	public PayrollGenerationException(String message) {
		super(message);
	}

}

package com.pay.main;

import com.pay.dao.*;
import com.pay.entity.*;
import com.pay.util.DatabaseConnection;
import com.pay.exception.*;

import java.sql.Connection;
import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Connection conn = DatabaseConnection.getConnection();

        IEmployeeService employeeService = new EmployeeService(conn);
        IPayrollService payrollService = new PayrollService(conn);
        ITaxService taxService = new TaxService(conn);
        IFinancialRecordService financialService = new FinancialRecordService(conn);

        boolean running = true;

        while (running) {
            System.out.println("\n===== PayXpert Payroll Management System =====");
            System.out.println("1. Employee Management");
            System.out.println("2. Payroll Management");
            System.out.println("3. Tax Management");
            System.out.println("4. Financial Records");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int mainChoice = sc.nextInt();
            sc.nextLine();

            try {
                switch (mainChoice) {
                    case 1 -> {
                        boolean empMenu = true;
                        while (empMenu) {
                            System.out.println("\n--- Employee Management ---");
                            System.out.println("1. Add Employee");
                            System.out.println("2. View All Employees");
                            System.out.println("3. Update Employee");
                            System.out.println("4. Delete Employee");
                            System.out.println("5. Get Employee by ID");
                            System.out.println("6. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int empChoice = sc.nextInt();
                            sc.nextLine();

                            switch (empChoice) {
                                case 1 -> {
                                    System.out.print("Employee ID: ");
                                    int eid = sc.nextInt(); sc.nextLine();
                                    System.out.print("First Name: ");
                                    String fname = sc.nextLine();
                                    System.out.print("Last Name: ");
                                    String lname = sc.nextLine();
                                    System.out.print("DOB (YYYY-MM-DD): ");
                                    LocalDate dob = LocalDate.parse(sc.nextLine());
                                    System.out.print("Gender: ");
                                    String gender = sc.nextLine();
                                    String email;
                                    while (true) {
                                        System.out.print("Email: ");
                                        email = sc.nextLine();
                                        if (ValidationService.isValidEmail(email)) break;
                                        else System.out.println("Invalid email. Try again.");
                                    }
                                    String phone;
                                    while (true) {
                                        System.out.print("Phone (10 digits): ");
                                        phone = sc.nextLine();
                                        if (ValidationService.isValidPhone(phone)) break;
                                        else System.out.println("Invalid phone. Try again.");
                                    }
                                    System.out.print("Address: ");
                                    String addr = sc.nextLine();
                                    System.out.print("Position: ");
                                    String pos = sc.nextLine();
                                    System.out.print("Joining Date (YYYY-MM-DD): ");
                                    LocalDate join = LocalDate.parse(sc.nextLine());
                                    System.out.print("Termination Date (blank or YYYY-MM-DD): ");
                                    String t = sc.nextLine();
                                    LocalDate term = t.isEmpty() ? null : LocalDate.parse(t);
                                    Employee e = new Employee(eid, fname, lname, dob, gender, email, phone, addr, pos, join, term);
                                    System.out.println(employeeService.addEmployee(e) ? "Employee added." : "Failed to add employee.");
                                }

                                case 2 -> employeeService.getAllEmployees().forEach(
                                        e -> System.out.println(e.getEmployeeId() + ": " + e.getFirstName() + " " + e.getLastName()));

                                case 3 -> {
                                    System.out.print("Enter Employee ID to update: ");
                                    int empId = sc.nextInt(); sc.nextLine();
                                    Employee old = employeeService.getEmployeeId(empId);
                                    System.out.print("First Name [" + old.getFirstName() + "]: ");
                                    String fname = sc.nextLine();
                                    System.out.print("Last Name [" + old.getLastName() + "]: ");
                                    String lname = sc.nextLine();
                                    System.out.print("Email [" + old.getEmail() + "]: ");
                                    String email = sc.nextLine();
                                    System.out.print("Phone [" + old.getPhoneNumber() + "]: ");
                                    String phone = sc.nextLine();
                                    old.setFirstName(fname.isEmpty() ? old.getFirstName() : fname);
                                    old.setLastName(lname.isEmpty() ? old.getLastName() : lname);
                                    old.setEmail(email.isEmpty() ? old.getEmail() : email);
                                    old.setPhoneNumber(phone.isEmpty() ? old.getPhoneNumber() : phone);
                                    System.out.println(employeeService.updateEmployee(old) ? "Employee updated." : "Failed to update.");
                                }

                                case 4 -> {
                                    System.out.print("Enter Employee ID to delete: ");
                                    int empId = sc.nextInt();
                                    System.out.println(employeeService.removeEmployee(empId) ? "Deleted." : "Failed.");
                                }

                                case 5 -> {
                                    System.out.print("Enter Employee ID: ");
                                    int id = sc.nextInt();
                                    Employee e = employeeService.getEmployeeId(id);
                                    System.out.println("Name: " + e.getFirstName() + " " + e.getLastName());
                                    System.out.println("Email: " + e.getEmail());
                                }

                                case 6 -> empMenu = false;
                                default -> System.out.println("Invalid choice.");
                            }
                        }
                    }

                    case 2 -> {
                        boolean payrollMenu = true;
                        while (payrollMenu) {
                            System.out.println("\n--- Payroll Management ---");
                            System.out.println("1. Generate Payroll");
                            System.out.println("2. View Payroll by ID");
                            System.out.println("3. View Payrolls by Date Range");
                            System.out.println("4. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int payrollChoice = sc.nextInt();
                            sc.nextLine();

                            switch (payrollChoice) {
                                case 1 -> {
                                    System.out.print("Payroll ID: ");
                                    int pid = sc.nextInt();
                                    System.out.print("Employee ID: ");
                                    int empId = sc.nextInt(); sc.nextLine();
                                    System.out.print("Start Date (YYYY-MM-DD): ");
                                    LocalDate start = LocalDate.parse(sc.nextLine());
                                    System.out.print("End Date (YYYY-MM-DD): ");
                                    LocalDate end = LocalDate.parse(sc.nextLine());
                                    System.out.print("Basic Salary: ");
                                    double basic = sc.nextDouble();
                                    System.out.print("Overtime Pay: ");
                                    double ot = sc.nextDouble();
                                    System.out.print("Deductions: ");
                                    double ded = sc.nextDouble();
                                    Payroll p = new Payroll(pid, empId, start, end, basic, ot, ded, 0);
                                    if (payrollService.generatePayroll(p)) {
                                        System.out.println("Payroll Generated.");
                                        Tax tObj = new Tax(pid, empId, LocalDate.now().getYear(), basic + ot - ded, 0);
                                        taxService.calculateTax(tObj);
                                        System.out.println("Tax calculated.");
                                    }
                                }

                                case 2 -> {
                                    System.out.print("Enter Payroll ID: ");
                                    int pid = sc.nextInt();
                                    Payroll p = payrollService.getPayrollById(pid);
                                    System.out.println("Employee ID: " + p.getEmployeeID());
                                    System.out.println("Net Salary: " + p.getNetSalary());
                                }

                                case 3 -> {
                                    System.out.print("Start Date (YYYY-MM-DD): ");
                                    LocalDate s = LocalDate.parse(sc.nextLine());
                                    System.out.print("End Date (YYYY-MM-DD): ");
                                    LocalDate e = LocalDate.parse(sc.nextLine());
                                    payrollService.getPayrollsForPeriod(s, e).forEach(
                                            p -> System.out.println("PayrollID: " + p.getPayrollID() + ", Net Salary: " + p.getNetSalary()));
                                }

                                case 4 -> payrollMenu = false;
                                default -> System.out.println("Invalid choice.");
                            }
                        }
                    }

                    case 3 -> {
                        boolean taxMenu = true;
                        while (taxMenu) {
                            System.out.println("\n--- Tax Management ---");
                            System.out.println("1. View Taxes for Employee");
                            System.out.println("2. Get Tax by ID");
                            System.out.println("3. Get Taxes for Year");
                            System.out.println("4. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int taxChoice = sc.nextInt();
                            sc.nextLine();

                            switch (taxChoice) {
                                case 1 -> {
                                    System.out.print("Employee ID: ");
                                    int eid = sc.nextInt();
                                    taxService.getTaxesForEmployee(eid).forEach(
                                            t -> System.out.println("Tax ID: " + t.getTaxID() + ", Tax Amount: " + t.getTaxAmount()));
                                }

                                case 2 -> {
                                    System.out.print("Enter Tax ID: ");
                                    int tid = sc.nextInt();
                                    Tax t = taxService.getTaxById(tid);
                                    System.out.println("Taxable Income: " + t.getTaxableIncome());
                                    System.out.println("Tax Amount: " + t.getTaxAmount());
                                }

                                case 3 -> {
                                    System.out.print("Enter Tax Year: ");
                                    int year = sc.nextInt();
                                    taxService.getTaxesForYear(year).forEach(
                                            t -> System.out.println("Employee ID: " + t.getEmployeeID() + ", Tax: " + t.getTaxAmount()));
                                }

                                case 4 -> taxMenu = false;
                                default -> System.out.println("Invalid choice.");
                            }
                        }
                    }

                    case 4 -> {
                        boolean finMenu = true;
                        while (finMenu) {
                            System.out.println("\n--- Financial Records ---");
                            System.out.println("1. Add Financial Record");
                            System.out.println("2. Get Record by ID");
                            System.out.println("3. Get Records for Date");
                            System.out.println("4. Back to Main Menu");
                            System.out.print("Enter your choice: ");
                            int finChoice = sc.nextInt();
                            sc.nextLine();

                            switch (finChoice) {
                                case 1 -> {
                                    System.out.print("Record ID: ");
                                    int rid = sc.nextInt();
                                    System.out.print("Employee ID: ");
                                    int eid = sc.nextInt(); sc.nextLine();
                                    System.out.print("Date (YYYY-MM-DD): ");
                                    LocalDate rdate = LocalDate.parse(sc.nextLine());
                                    System.out.print("Description: ");
                                    String desc = sc.nextLine();
                                    System.out.print("Amount: ");
                                    double amt = sc.nextDouble(); sc.nextLine();
                                    System.out.print("Type (income/expense): ");
                                    String type = sc.nextLine();
                                    FinancialRecord fr = new FinancialRecord(rid, eid, rdate, desc, amt, type);
                                    System.out.println(financialService.addFinancialRecord(fr) ? "Record added." : "Failed to add.");
                                }

                                case 2 -> {
                                    System.out.print("Enter Record ID: ");
                                    int rid = sc.nextInt();
                                    FinancialRecord fr = financialService.getFinancialRecordById(rid);
                                    System.out.println("Employee ID: " + fr.getEmployeeID());
                                    System.out.println("Type: " + fr.getRecordType() + ", Amount: " + fr.getAmount());
                                }

                                case 3 -> {
                                    System.out.print("Enter Record Date (YYYY-MM-DD): ");
                                    LocalDate date = LocalDate.parse(sc.nextLine());
                                    financialService.getFinancialRecordsForDate(date).forEach(
                                            r -> System.out.println("ID: " + r.getRecordID() + ", EmpID: " + r.getEmployeeID() + ", Amount: " + r.getAmount()));
                                }

                                case 4 -> finMenu = false;
                                default -> System.out.println("Invalid choice.");
                            }
                        }
                    }

                    case 5 -> {
                        running = false;
                        System.out.println("Exiting PayXpert.");
                    }

                    default -> System.out.println("Invalid choice. Try again.");
                }
            } catch (Exception ex) {
                System.err.println("Error: " + ex.getMessage());
            }
        }

        System.out.println("Application Exited.");
        sc.close();
    }
}

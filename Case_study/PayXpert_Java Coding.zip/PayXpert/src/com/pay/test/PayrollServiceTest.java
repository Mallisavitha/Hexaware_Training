package com.pay.test;

import com.pay.entity.Payroll;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

class PayrollServiceTest {

	@Test
	void testCalculateGrossSalary() {
		Payroll payroll=new Payroll(101,1,
				LocalDate.of(2024, 1, 1), LocalDate.of(2024, 1, 31),
				50000,10000,500,0);
		
		double expectedGross=60000;
		double actualGross=payroll.getBasicSalary()+payroll.getOvertimePay();
		assertEquals(expectedGross,actualGross);
	}
	
	@Test
	void testCalculateNetSalary() {
		Payroll payroll=new Payroll(102,2,LocalDate.of(2024, 2, 1),
				LocalDate.of(2024, 2, 28),60000,5000,7000,0);
		
		double expectedNet=58000;
		double actualNet=payroll.getBasicSalary()+payroll.getOvertimePay()-payroll.getDeductions();
		assertEquals(expectedNet,actualNet);
		
	}
	
	@Test
	void testProcessPayrollBatch() {
		List<Payroll> payrollList=List.of(
				new Payroll(301,4,LocalDate.now(),LocalDate.now(),40000,2000,3000,0),
				new Payroll(302,5,LocalDate.now(),LocalDate.now(),55000,5000,4500,0)
				);
		for (Payroll p :payrollList) {
			double net=p.getBasicSalary()+p.getOvertimePay()-p.getDeductions();
			p.setNetSalary(net);
			assertTrue(p.getNetSalary()>0);
		}
	}

}

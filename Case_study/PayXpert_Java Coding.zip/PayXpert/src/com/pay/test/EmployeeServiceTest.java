package com.pay.test;

import com.pay.entity.Employee;
import com.pay.exception.InvalidInputException;
import com.pay.dao.EmployeeService;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class EmployeeServiceTest {

	@Test
    void testNegativeEmployeeIdThrowsException() {
        EmployeeService service = new EmployeeService(null);  // null because DB is not touched

        Employee emp = new Employee();
        emp.setEmployeeId(-5);
        emp.setFirstName("John");
        emp.setLastName("Doe");
        emp.setDateOfBirth(LocalDate.of(1995, 1, 1));
        emp.setJoiningDate(LocalDate.now());

        assertThrows(InvalidInputException.class, () -> {
            service.validateEmployee(emp);
        });
    }

    @Test
    void testMissingFirstNameThrowsException() {
        EmployeeService service = new EmployeeService(null);

        Employee emp = new Employee();
        emp.setEmployeeId(10);
        emp.setFirstName(""); // invalid
        emp.setLastName("Doe");
        emp.setDateOfBirth(LocalDate.of(1990, 1, 1));
        emp.setJoiningDate(LocalDate.now());

        assertThrows(InvalidInputException.class, () -> {
            service.validateEmployee(emp);
        });
    }

    @Test
    void testValidEmployeeDataDoesNotThrow() {
        EmployeeService service = new EmployeeService(null);

        Employee emp = new Employee();
        emp.setEmployeeId(101);
        emp.setFirstName("John");
        emp.setLastName("Doe");
        emp.setDateOfBirth(LocalDate.of(1990, 1, 1));
        emp.setGender("Male");
        emp.setEmail("john@example.com");
        emp.setPhoneNumber("9999999999");
        emp.setAddress("City");
        emp.setPosition("Engineer");
        emp.setJoiningDate(LocalDate.of(2023, 1, 1));
        emp.setTerminationDate(null);

        // We just check no exception thrown (we won’t insert into DB because conn is null)
        assertDoesNotThrow(() -> {
            service.validateEmployee(emp);
        });
    }

	

}

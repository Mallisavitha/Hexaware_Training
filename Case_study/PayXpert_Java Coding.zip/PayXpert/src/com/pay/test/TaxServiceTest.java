package com.pay.test;

import com.pay.entity.Tax;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaxServiceTest {

	@Test
	void testTaxCalculationHighIncome() {
		Tax tax=new Tax(201,3,2024,1200000,0); //High Income case
		double expectedTax=1200000*0.30; //30% slab
		tax.setTaxAmount(expectedTax);
		assertEquals(expectedTax,tax.getTaxAmount());
	}

}

package com.pay.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.pay.exception.DatabaseConnectionException;

public class DatabaseConnection {
	private static final String URL = "jdbc:mysql://localhost:3306/payxpert?autoReconnect=true&useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "malli0715";
    private static Connection connection;

    private DatabaseConnection() {}

    public static Connection getConnection() {
        if (connection == null) {
            try {
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Connection Established");
            } 
            catch (SQLException e) {
                throw new DatabaseConnectionException("Database Connection Failed: " + e.getMessage());
            }
        }
        return connection;
    }

}

package com.sis.main;

import java.time.LocalDate;
import java.util.*;
import java.sql.Connection;

import com.sis.exception.*;
import com.sis.dao.*;
import com.sis.entity.*;
import com.sis.util.DatabaseConnection;

public class Main {
	public static void main(String args[]) {
		Connection conn=DatabaseConnection.getConnection();
		Scanner sc=new Scanner(System.in);
		
		StudentDAO studentDao=new StudentDAOImpl(conn);
		TeacherDAO teacherDao=new TeacherDAOImpl(conn);
		CourseDAO courseDao=new CourseDAOImpl(conn);
		EnrollmentDAO enrollmentDao=new EnrollmentDAOImpl(conn);
		PaymentDAO paymentDao=new PaymentDAOImpl(conn);
		
		while(true) {
			System.out.println("\n===== STUDENT INFORMATION SYSTEM =====");
			System.out.println("1. Add Student");
			System.out.println("2. Add Teacher");
			System.out.println("3. Add Course");
			System.out.println("4. Assign Teacher to Course");
			System.out.println("5. Enroll Student to Course");
			System.out.println("6. Add Payment");
			System.out.println("7. View All Students");
			System.out.println("8. View All Teachers");
			System.out.println("9. View All Courses");
			System.out.println("10. View All Enrollments");
			System.out.println("11. View All Payments");
			System.out.println("0. Exit");
			System.out.println("Enter Your Choice: ");
			int choice=sc.nextInt();
			
			switch(choice) {
			
				case 1 ->{
					System.out.print("Enter Student ID: ");
					int id=sc.nextInt();
					sc.nextLine();
					System.out.print("First Name: ");
					String fn=sc.nextLine();
					System.out.print("Last Name: ");
					String ln=sc.nextLine();
					System.out.print("Date of Birth (YYYY-MM-DD): ");
					LocalDate dob=LocalDate.parse(sc.nextLine());
					System.out.print("Email: ");
					String email=sc.nextLine();
					System.out.print("Phone: ");
					long phone=sc.nextLong();
					
					try {
                         Student student = new Student(id, fn, ln, dob, email, phone);
                         studentDao.addStudent(student);
                         System.out.println("Student added successfully!");
                            
                    } 
					catch (InvalidStudentDataException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
				}
				
				case 2 ->{
					System.out.print("Enter Teacher ID: ");
					int id=sc.nextInt();
					sc.nextLine();
					System.out.print("First Name: ");
					String fn=sc.nextLine();
					System.out.print("Last Name: ");
					String ln=sc.nextLine();
					System.out.print("Email: ");
					String email=sc.nextLine();
					
					try {
						Teacher teacher=new Teacher(id,fn,ln,email);
						teacherDao.addTeacher(teacher);
						System.out.println("Teacher added successfully!");
					}
					 catch (InvalidTeacherDataException e) {
                         System.out.println("Error: " + e.getMessage());
                     }
				}
				
				 case 3 -> {
	                    System.out.print("Enter Course ID: ");
	                    int id = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Course Name: ");
	                    String name = sc.nextLine();
	                    System.out.print("Credits: ");
	                    int credits = sc.nextInt();
	                    System.out.print("Teacher ID: ");
	                    int tid = sc.nextInt();

	                    try {
	                    	Course course = new Course(id, name, credits, tid);
	                    	courseDao.addCourse(course);
	                    	System.out.println("Course added successfully!");
	                    }
	                    catch (InvalidCourseDataException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
	                }
				 
				 case 4 -> {
	                    System.out.print("Enter Course ID: ");
	                    int cid = sc.nextInt();
	                    System.out.print("Enter Teacher ID: ");
	                    int tid = sc.nextInt();

	                    try {
	                    	Teacher teacher = teacherDao.getTeacherById(tid);
	                    	courseDao.assignTeacher(cid, teacher);
	                    	System.out.println("Teacher assigned successfully!");
	                    }
	                    catch (TeacherNotFoundException | CourseNotFoundException e) {
                            System.out.println("Error: " + e.getMessage());
	                    } 
	                }
				
				 case 5 -> {
	                    System.out.print("Enter Enrollment ID: ");
	                    int eid = sc.nextInt();
	                    System.out.print("Student ID: ");
	                    int sid = sc.nextInt();
	                    System.out.print("Course ID: ");
	                    int cid = sc.nextInt();
	                    sc.nextLine();
	                    System.out.print("Enrollment Date (yyyy-mm-dd): ");
	                    LocalDate date = LocalDate.parse(sc.nextLine());

	                    try {
	                    	Enrollment enrollment = new Enrollment(eid, sid, cid, date);
	                    	enrollmentDao.addEnrollment(enrollment);
	                    	System.out.println("Enrollment recorded successfully!");
	                    }
	                    catch (DuplicateEnrollmentException | StudentNotFoundException | CourseNotFoundException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
	                }

	                case 6 -> {
	                    System.out.print("Enter Payment ID: ");
	                    int pid = sc.nextInt();
	                    System.out.print("Student ID: ");
	                    int sid = sc.nextInt();
	                    System.out.print("Amount: ");
	                    double amt = sc.nextDouble();
	                    sc.nextLine();
	                    System.out.print("Payment Date (yyyy-mm-dd): ");
	                    LocalDate date = LocalDate.parse(sc.nextLine());

	                    try {
	                    	 if (amt <= 0) {
	                                throw new PaymentValidationException("Payment amount must be greater than zero.");
	                    	 }
	                    	 Payment payment = new Payment(pid, sid, amt, date);
	                    	 paymentDao.addPayment(payment);
	                    	 System.out.println("Payment recorded successfully!");
	                    }
	                    catch (PaymentValidationException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
	                }

	                case 7 -> {
	                    List<Student> students = studentDao.getAllStudents();
	                    System.out.println("\n--- All Students ---");
	                    for (Student s : students) {
	                        System.out.println(s.getStudentId() + ": " + s.getFirstName() + " " + s.getLastName());
	                    }
	                }

	                case 8 -> {
	                    List<Teacher> teachers = teacherDao.getAllTeachers();
	                    System.out.println("\n--- All Teachers ---");
	                    for (Teacher t : teachers) {
	                        System.out.println(t.getTeacherId() + ": " + t.getFirstName() + " " + t.getLastName());
	                    }
	                }

	                case 9 -> {
	                    List<Course> courses = courseDao.getAllCourses();
	                    System.out.println("\n--- All Courses ---");
	                    for (Course c : courses) {
	                        System.out.println(c.getCourseId() + ": " + c.getCourseName() + " (" + c.getCredits() + " credits)");
	                    }
	                }

	                case 10 -> {
	                    List<Enrollment> enrollments = enrollmentDao.getAllEnrollments();
	                    System.out.println("\n--- All Enrollments ---");
	                    for (Enrollment e : enrollments) {
	                        System.out.println("Enrollment ID: " + e.getEnrollmentId() + ", Student: " + e.getStudentId() + ", Course: " + e.getCourseId());
	                    }
	                }

	                case 11 -> {
	                    List<Payment> payments = paymentDao.getAllPayments();
	                    System.out.println("\n--- All Payments ---");
	                    for (Payment p : payments) {
	                        System.out.println("Payment ID: " + p.getPaymentId() + ", Student: " + p.getStudentId() + ", Amount: " + p.getAmount());
	                    }
	                }

	                case 0 -> {
	                    System.out.println("Exiting system. Goodbye!");
	                    sc.close();
	                    return;
	                }

	                default -> System.out.println("Invalid choice. Try again.");
	            
			}
		}
	}

}

package com.sis.dao;

import com.sis.entity.Teacher;
import com.sis.entity.Course;

import java.util.List;

public interface TeacherDAO {
	void addTeacher(Teacher teacher);
    void updateTeacherInfo(int teacherId, String firstName, String lastName, String email);
    Teacher getTeacherById(int teacherId);
    List<Teacher> getAllTeachers();
    List<Course> getAssignedCourses(int teacherId);

}

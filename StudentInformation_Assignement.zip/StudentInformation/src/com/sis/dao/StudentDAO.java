package com.sis.dao;

import com.sis.entity.Student;
import com.sis.entity.Course;
import com.sis.entity.Payment;

import java.util.List;

public interface StudentDAO {
	void addStudent(Student student);
    void updateStudentInfo(int studentId, String firstName, String lastName, String dob, String email, long phone);
    void enrollInCourse(int studentId, int courseId, String enrollmentDate);
    void makePayment(int studentId, double amount, String paymentDate);
    Student getStudentById(int studentId);
    List<Student> getAllStudents();
    List<Course> getEnrolledCourses(int studentId);
    List<Payment> getPaymentHistory(int studentId);

}

package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Teacher;


import java.util.List;

public interface CourseDAO {
 
	void addCourse(Course course);
    void updateCourseInfo(int courseId, String courseCode, String courseName, int teacherId);
    void assignTeacher(int courseId, Teacher teacher);
    Course getCourseById(int courseId);
    List<Course> getAllCourses();
    List<Integer> getEnrollments(int courseId);
    Teacher getAssignedTeacher(int courseId);

}

package com.sis.dao;

import com.sis.entity.Teacher;
import com.sis.entity.Course;
import com.sis.exception.InvalidTeacherDataException;
import com.sis.exception.TeacherNotFoundException;
import com.sis.exception.CourseNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAOImpl implements TeacherDAO {
	private Connection conn;
	
	public TeacherDAOImpl(Connection conn) {
		this.conn=conn;
	}

	@Override
	public void addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		if (teacher.getFirstName() == null || teacher.getLastName() == null || teacher.getEmail() == null) {
	        throw new InvalidTeacherDataException("Teacher data cannot be null.");
	    }
		 String query = "INSERT INTO Teacher (first_name, last_name, email) VALUES (?, ?, ?)";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setString(1, teacher.getFirstName());
	            ps.setString(2, teacher.getLastName());
	            ps.setString(3, teacher.getEmail());
	            ps.executeUpdate();
	        } 
	        catch (SQLException e) {
	        	throw new InvalidTeacherDataException("Error: "+e.getMessage());
	        }
		
	}

	@Override
	public void updateTeacherInfo(int teacherId, String firstName, String lastName, String email) {
		// TODO Auto-generated method stub
		if (firstName == null || lastName == null || email == null) {
	        throw new InvalidTeacherDataException("Updated teacher info cannot be null.");
	    }
		String query = "UPDATE Teacher SET first_name = ?, last_name = ?, email = ? WHERE teacher_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, email);
            ps.setInt(4, teacherId);
            ps.executeUpdate();
        } 
        catch (SQLException e) {
        	throw new InvalidTeacherDataException("Error: "+e.getMessage());
        }
	}

	@Override
	public Teacher getTeacherById(int teacherId) {
		// TODO Auto-generated method stub
		Teacher teacher = null;
        String query = "SELECT * FROM Teacher WHERE teacher_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, teacherId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                teacher = new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email")
                );
            }
            else {
                throw new TeacherNotFoundException("Teacher with ID " + teacherId + " not found.");
            }
        } 
        catch (SQLException e) {
        	throw new TeacherNotFoundException("Error to retrieve teacher: "+e.getMessage());
        }
        return teacher;
	}

	@Override
	public List<Teacher> getAllTeachers() {
		// TODO Auto-generated method stub
		List<Teacher> teachers = new ArrayList<>();
        String query = "SELECT * FROM Teacher";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Teacher teacher = new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email")
                );
                teachers.add(teacher);
            }
        } 
        catch (SQLException e) {
        	throw new TeacherNotFoundException("Error: "+e.getMessage());
        }
        return teachers;
	}

	@Override
	public List<Course> getAssignedCourses(int teacherId) {
		// TODO Auto-generated method stub
		List<Course> courses = new ArrayList<>();
        String query = "SELECT * FROM Courses WHERE teacher_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, teacherId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Course course = new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getInt("credits"),
                    rs.getInt("teacher_id")
                );
                courses.add(course);
            }
        } 
        catch (SQLException e) {
	          throw new CourseNotFoundException("Error: "+e.getMessage());
        }
        return courses;
	}

}

package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Teacher;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.InvalidCourseDataException;
import com.sis.exception.TeacherNotFoundException;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAOImpl implements CourseDAO{
	private Connection conn;
	
	public CourseDAOImpl(Connection conn) {
		this.conn=conn;
	}

	@Override
	public void addCourse(Course course) {
		// TODO Auto-generated method stub
		if(course.getCourseName()==null || course.getCourseName().isEmpty()) {
			throw new InvalidCourseDataException("Course name cannot be null or empty");
		}
		 String query = "INSERT INTO Courses (course_name, credits, teacher_id) VALUES (?, ?, ?)";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setString(1, course.getCourseName());
	            ps.setInt(2, course.getCredits());
	            ps.setInt(3, course.getTeacherId()); 
	            ps.executeUpdate();
	        } 
	        catch (SQLException e) {
	        	throw new InvalidCourseDataException("Error adding course: "+e.getMessage());
	        }
		
	}

	@Override
	public void updateCourseInfo(int courseId, String courseCode, String courseName, int teacherId) {
		// TODO Auto-generated method stub
		if(courseName==null || courseName.isEmpty()) {
			throw new InvalidCourseDataException("Course name connot be null or empty");
		}
		 String query = "UPDATE Courses SET course_name = ?, teacher_id = ? WHERE course_id = ?";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setString(1, courseName);
	            ps.setInt(2, teacherId);
	            ps.setInt(3, courseId);
	            ps.executeUpdate();
	        } 
	        catch (SQLException e) {
	        	throw new InvalidCourseDataException("Error updating course: "+e.getMessage());
	        }
		
	}

	@Override
	public void assignTeacher(int courseId, Teacher teacher) {
		// TODO Auto-generated method stub
		if(teacher == null || teacher.getTeacherId()==0) {
			throw new TeacherNotFoundException("Invalid teacher information.");
		}
		 String query = "UPDATE Courses SET teacher_id = ? WHERE course_id = ?";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, teacher.getTeacherId());
	            ps.setInt(2, courseId);
	            int updated = ps.executeUpdate();
	            if (updated == 0) {
	                throw new CourseNotFoundException("Course with ID " + courseId + " not found.");
	            }
	        } 
	        catch (SQLException e) {
	        	throw new TeacherNotFoundException("Error assigning teacher: "+e.getMessage());
	        }
		
	}

	@Override
	public Course getCourseById(int courseId) {
		// TODO Auto-generated method stub
		  Course course = null;
	        String query = "SELECT * FROM Courses WHERE course_id = ?";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, courseId);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                course = new Course(
	                        rs.getInt("course_id"),
	                        rs.getString("course_name"),
	                        rs.getInt("credits"),
	                        rs.getInt("teacher_id") // Assuming teacher_id is stored in the Course table
	                );
	            }
	            else {
	            	throw new CourseNotFoundException("Course with ID "+courseId+" not found.");
	            }
	        } 
	        catch (SQLException e) {
	        	throw new CourseNotFoundException("Error: "+e.getMessage());
	        }
	        return course;
	}

	@Override
	public List<Course> getAllCourses() {
		// TODO Auto-generated method stub
		List<Course> courses = new ArrayList<>();
        String query = "SELECT * FROM Courses";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Course course = new Course(
                        rs.getInt("course_id"),
                        rs.getString("course_name"),
                        rs.getInt("credits"),
                        rs.getInt("teacher_id")
                );
                courses.add(course);
            }
        } 
        catch (SQLException e) {
        	throw new InvalidCourseDataException("Error fetching courses: "+e.getMessage());
        }
        return courses;
	}

	@Override
	public List<Integer> getEnrollments(int courseId) {
		// TODO Auto-generated method stub
		List<Integer> enrollmentIds = new ArrayList<>();
        String query = "SELECT enrollment_id FROM Enrollments WHERE course_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                enrollmentIds.add(rs.getInt("enrollment_id"));
            }
        } 
        catch (SQLException e) {
        	throw new CourseNotFoundException("Error fetching enrollments: "+e.getMessage());
        }
        return enrollmentIds;
	}

	@Override
	public Teacher getAssignedTeacher(int courseId) {
		// TODO Auto-generated method stub
		Teacher teacher = null;
        String query = "SELECT t.teacher_id, t.first_name, t.last_name, t.email " +
                "FROM Teacher t INNER JOIN Courses c ON t.teacher_id = c.teacher_id " +
                "WHERE c.course_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, courseId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                teacher = new Teacher(
                        rs.getInt("teacher_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email")
                );
            }
            else {
                throw new TeacherNotFoundException("No teacher assigned to course with ID " + courseId);
            }
        } 
        catch (SQLException e) {
        	throw new TeacherNotFoundException("Error retrieving teacher: "+e.getMessage());
        }
        return teacher;
	}
}
		
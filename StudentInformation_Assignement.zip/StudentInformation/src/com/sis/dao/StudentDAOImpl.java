package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.exception.StudentNotFoundException;
import com.sis.exception.InvalidStudentDataException;
import com.sis.exception.InsufficientFundsException;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.InvalidEnrollmentDataException;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {
	private Connection conn;
	
	public StudentDAOImpl(Connection conn) {
		this.conn=conn;
	}

	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		if (student == null || student.getFirstName() == null || student.getEmail() == null) {
            throw new InvalidStudentDataException("Invalid student data provided.");
        }
		String query = "INSERT INTO Students (student_id, first_name, last_name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, student.getStudentId());
            stmt.setString(2, student.getFirstName());
            stmt.setString(3, student.getLastName());
            stmt.setDate(4, Date.valueOf(student.getDateOfBirth()));
            stmt.setString(5, student.getEmail());
            stmt.setLong(6, student.getPhoneNumber());
            stmt.executeUpdate();
        } 
        catch (SQLException e) {
            throw new InvalidStudentDataException("Error adding student: " + e.getMessage());        
        }
	
	}

	@Override
	public void updateStudentInfo(int studentId, String firstName, String lastName, String dob, String email,
			long phone) {
		// TODO Auto-generated method stub
		String query = "UPDATE Students SET first_name=?, last_name=?, date_of_birth=?, email=?, phone_number=? WHERE student_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, Date.valueOf(dob));
            stmt.setString(4, email);
            stmt.setLong(5, phone);
            stmt.setInt(6, studentId);
            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new StudentNotFoundException("Student with ID " + studentId + " not found.");
            }
        } 
        catch (SQLException e) {
        	throw new StudentNotFoundException("Error updating student: " + e.getMessage());
        }
		
	}

	@Override
	public void enrollInCourse(int studentId, int courseId, String enrollmentDate) {
		// TODO Auto-generated method stub
		String query = "INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.setDate(3, Date.valueOf(enrollmentDate));
            stmt.executeUpdate();
        } 
        catch (SQLException e) {
            throw new CourseNotFoundException("Error enrolling in course: "+e.getMessage());
        }
		
	}

	@Override
	public void makePayment(int studentId, double amount, String paymentDate) {
		// TODO Auto-generated method stub
		if (amount <= 0) {
            throw new InsufficientFundsException("Payment amount must be greater than 0.");
        }
		String query = "INSERT INTO Payments (student_id, amount, payment_date) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            stmt.setDouble(2, amount);
            stmt.setDate(3, Date.valueOf(paymentDate));
            stmt.executeUpdate();
        } 
        catch (SQLException e) {
            throw new InsufficientFundsException("Error making payment: "+e.getMessage());
        }
		
	}

	@Override
	public Student getStudentById(int studentId) {
		// TODO Auto-generated method stub
		String query = "SELECT * FROM Students WHERE student_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Student(
                    rs.getInt("student_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("date_of_birth").toLocalDate(),
                    rs.getString("email"),
                    rs.getLong("phone_number")
                );
            }
            else {
                throw new StudentNotFoundException("Student with ID " + studentId + " not found.");
            }
        } 
        catch (SQLException e) {
        	throw new StudentNotFoundException("Error retrieving  student: "+e.getMessage());
        }

	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		List<Student> students = new ArrayList<>();
        String query = "SELECT * FROM Students";
        try (Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                students.add(new Student(
                    rs.getInt("student_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getDate("date_of_birth").toLocalDate(),
                    rs.getString("email"),
                    rs.getLong("phone_number")
                ));
            }
        } 
        catch (SQLException e) {
        	throw new StudentNotFoundException("Error retrieving students: "+e.getMessage());
        }
        return students;
	}

	@Override
	public List<Course> getEnrolledCourses(int studentId) {
		// TODO Auto-generated method stub
		List<Course> courses = new ArrayList<>();
        String query = "SELECT c.course_id, c.course_name, c.credits, c.teacher_id " +
                       "FROM Courses c JOIN Enrollments e ON c.course_id = e.course_id WHERE e.student_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                courses.add(new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getInt("credits"),
                    rs.getInt("teacher_id")
                ));
            }
        } 
        catch (SQLException e) {
            throw new InvalidEnrollmentDataException("Error retrieving enrolled course: "+e.getMessage());
        }
        return courses;
	}

	@Override
	public List<Payment> getPaymentHistory(int studentId) {
		// TODO Auto-generated method stub
		List<Payment> payments = new ArrayList<>();
        String query = "SELECT * FROM Payments WHERE student_id=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                payments.add(new Payment(
                    rs.getInt("payment_id"),
                    rs.getInt("student_id"),
                    rs.getDouble("amount"),
                    rs.getDate("payment_date").toLocalDate()
                ));
            }
        } 
        catch (SQLException e) {
            throw new InsufficientFundsException("Error: "+e.getMessage());
        }
        return payments;
	}
}

	
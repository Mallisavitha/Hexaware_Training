package com.sis.dao;

import com.sis.entity.Enrollment;

import java.util.List;

public interface EnrollmentDAO {
	void addEnrollment(Enrollment enrollment);
    Enrollment getEnrollmentById(int enrollmentId);
    List<Enrollment> getAllEnrollments();
    int getStudentByEnrollmentId(int enrollmentId);
    int getCourseByEnrollmentId(int enrollmentId);

}

package com.sis.dao;

import com.sis.entity.Enrollment;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.DuplicateEnrollmentException;
import com.sis.exception.InvalidEnrollmentDataException;
import com.sis.exception.StudentNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAOImpl implements EnrollmentDAO {
	
private Connection conn;
	
	public EnrollmentDAOImpl(Connection conn) {
		this.conn=conn;
	}

	@Override
	public void addEnrollment(Enrollment enrollment) {
		// TODO Auto-generated method stub
		if (enrollment.getStudentId() <= 0 || enrollment.getCourseId() <= 0 || enrollment.getEnrollmentDate() == null) {
            throw new InvalidEnrollmentDataException("Invalid enrollment data provided.");
        }
        
        // Insert enrollment
		String query = "INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, enrollment.getStudentId());
            ps.setInt(2, enrollment.getCourseId());
            ps.setDate(3, Date.valueOf(enrollment.getEnrollmentDate())); // Converting LocalDate to java.sql.Date
            ps.executeUpdate();;
        } 
        catch (SQLException e) {
        	throw new DuplicateEnrollmentException("Error adding enrollment: "+e.getMessage());
        }
		
	}

	@Override
	public Enrollment getEnrollmentById(int enrollmentId) {
		// TODO Auto-generated method stub
		 Enrollment enrollment = null;
	        String query = "SELECT * FROM Enrollments WHERE enrollment_id = ?";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, enrollmentId);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                enrollment = new Enrollment(
	                        rs.getInt("enrollment_id"),
	                        rs.getInt("student_id"),
	                        rs.getInt("course_id"),
	                        rs.getDate("enrollment_date").toLocalDate() // Convert java.sql.Date to LocalDate
	                );
	            }
	        } 
	        catch (SQLException e) {
	            throw new InvalidEnrollmentDataException("Error retrieving enrollment: "+e.getMessage());
	        }
	        return enrollment;
	}

	@Override
	public List<Enrollment> getAllEnrollments() {
		// TODO Auto-generated method stub
		List<Enrollment> enrollments = new ArrayList<>();
        String query = "SELECT * FROM Enrollments";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Enrollment e = new Enrollment(
                        rs.getInt("enrollment_id"),
                        rs.getInt("student_id"),
                        rs.getInt("course_id"),
                        rs.getDate("enrollment_date").toLocalDate() // Convert java.sql.Date to LocalDate
                );
                enrollments.add(e);
            }
        } 
        catch (SQLException e) {
        	throw new InvalidEnrollmentDataException("Error retrieving all enrollments: "+e.getMessage());
        }
        return enrollments;
	}

	@Override
	public int getStudentByEnrollmentId(int enrollmentId) {
		// TODO Auto-generated method stub
		int studentId = -1;
        String query = "SELECT student_id FROM Enrollments WHERE enrollment_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, enrollmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                studentId = rs.getInt("student_id");
            }
        } 
        catch (SQLException e) {
        	throw new StudentNotFoundException("Error fetching student ID: "+e.getMessage());
        }
        return studentId;
	}

	@Override
	public int getCourseByEnrollmentId(int enrollmentId) {
		// TODO Auto-generated method stub
		int courseId = -1;
        String query = "SELECT course_id FROM Enrollments WHERE enrollment_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, enrollmentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                courseId = rs.getInt("course_id");
            }
        } 
        catch (SQLException e) {
        	throw new CourseNotFoundException ("Error fetching course ID: "+e.getMessage());
        }
        return courseId;
	}
	

}

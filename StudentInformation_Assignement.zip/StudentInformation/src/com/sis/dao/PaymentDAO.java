package com.sis.dao;

import com.sis.entity.Payment;

import java.util.List;

public interface PaymentDAO {
	void addPayment(Payment payment);
    Payment getPaymentById(int paymentId);
    List<Payment> getAllPayments();
    int getStudentByPaymentId(int paymentId);
    double getPaymentAmount(int paymentId);
    String getPaymentDate(int paymentId);
}

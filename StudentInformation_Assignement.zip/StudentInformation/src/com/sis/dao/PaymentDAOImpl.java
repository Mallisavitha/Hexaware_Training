package com.sis.dao;

import com.sis.entity.Payment;
import com.sis.exception.PaymentValidationException;
import com.sis.exception.StudentNotFoundException;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAOImpl implements PaymentDAO{
private Connection conn;
	
	public PaymentDAOImpl(Connection conn) {
		this.conn=conn;
	}

	@Override
	public void addPayment(Payment payment) {
		// TODO Auto-generated method stub
		 if (payment == null || payment.getAmount() <= 0 || payment.getPaymentDate() == null || payment.getStudentId() <= 0) {
	            throw new PaymentValidationException("Invalid payment data provided.");
	        }
		String query = "INSERT INTO Payments (student_id, amount, payment_date) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, payment.getStudentId());
            ps.setDouble(2, payment.getAmount());
            ps.setDate(3, Date.valueOf(payment.getPaymentDate()));
            ps.executeUpdate();
        } 
        catch (SQLException e) {
        	throw new PaymentValidationException("Error: "+e.getMessage());
        }
	}

	@Override
	public Payment getPaymentById(int paymentId) {
		// TODO Auto-generated method stub
		Payment payment = null;
        String query = "SELECT * FROM Payments WHERE payment_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, paymentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                payment = new Payment(
                    rs.getInt("payment_id"),
                    rs.getInt("student_id"),
                    rs.getDouble("amount"),
                    rs.getDate("payment_date").toLocalDate()
                );
            }
            else {
                throw new PaymentValidationException("Payment with ID " + paymentId + " not found.");
            }
        } 
        catch (SQLException e) {
        	throw new PaymentValidationException("Error retrieving payment: " + e.getMessage());  
        }
        return payment;
	}

	@Override
	public List<Payment> getAllPayments() {
		// TODO Auto-generated method stub
		 List<Payment> payments = new ArrayList<>();
	     String query = "SELECT * FROM Payments";
	     try (PreparedStatement ps = conn.prepareStatement(query)) {
	          ResultSet rs = ps.executeQuery();
	          while (rs.next()) {
	              Payment payment = new Payment(
	                  rs.getInt("payment_id"),
	                  rs.getInt("student_id"),
	                  rs.getDouble("amount"),
	                  rs.getDate("payment_date").toLocalDate()
	              );
	              payments.add(payment);
	          }
	     } 
	     catch (SQLException e) {
	    	 throw new PaymentValidationException("Error retrievig payments: "+e.getMessage());
	     }
        return payments;
	}

	@Override
	public int getStudentByPaymentId(int paymentId) {
		// TODO Auto-generated method stub
		    int studentId = -1;
	        String query = "SELECT student_id FROM Payments WHERE payment_id = ?";
	        try (PreparedStatement ps = conn.prepareStatement(query)) {
	            ps.setInt(1, paymentId);
	            ResultSet rs = ps.executeQuery();
	            if (rs.next()) {
	                studentId = rs.getInt("student_id");
	            }
	        } 
	        catch (SQLException e) {
	        	throw new StudentNotFoundException("Error fetching student ID from payment: "+e.getMessage());
	        }
	        return studentId;
	}

	@Override
	public double getPaymentAmount(int paymentId) {
		// TODO Auto-generated method stub
		double amount = 0.0;
        String query = "SELECT amount FROM Payments WHERE payment_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, paymentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                amount = rs.getDouble("amount");
            }
        } 
        catch (SQLException e) {
        	throw new PaymentValidationException("Error fetching payment amount: "+e.getMessage());
        }
        return amount;
	}

	@Override
	public String getPaymentDate(int paymentId) {
		// TODO Auto-generated method stub
        String date = null;
        String query = "SELECT payment_date FROM Payments WHERE payment_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, paymentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                date = rs.getDate("payment_date").toString();
            }
        } 
        catch (SQLException e) {
        	throw new PaymentValidationException("Error fetching payment date: "+e.getMessage());
        }
        return date;

	}

	

}

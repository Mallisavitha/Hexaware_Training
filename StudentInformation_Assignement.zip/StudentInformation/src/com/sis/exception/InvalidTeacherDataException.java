package com.sis.exception;

public class InvalidTeacherDataException extends RuntimeException {
	public InvalidTeacherDataException(String message) {
		super(message);
	}

}

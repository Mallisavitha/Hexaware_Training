package com.loan.dao;

import com.loan.entity.*;
import com.loan.exception.*;

import java.sql.*;
import java.util.*;

public class LoanRepositoryImpl implements ILoanRepository {
	private Connection conn;
	public LoanRepositoryImpl(Connection conn) {
		this.conn=conn;
	}
	
	@Override
	public void applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		try (Scanner sc = new Scanner(System.in)) {
	        System.out.print("Do you want to proceed with the loan application? (Yes/No): ");
	        String confirm = sc.nextLine();
	        if (!confirm.equalsIgnoreCase("Yes")) {
	            System.out.println("Loan application cancelled.");
	            return;
	        }

	        //Check if customer exists
	        String checkSql = "SELECT customerId FROM Customer WHERE customerId = ?";
	        PreparedStatement checkPs = conn.prepareStatement(checkSql);
	        checkPs.setInt(1, loan.getCustomer().getCustomerId());
	        ResultSet rs = checkPs.executeQuery();

	        //Insert customer if not exists
	        if (!rs.next()) {
	            String insertCustomerSql = "INSERT INTO Customer (customerId, name, email, phone, address, creditScore) VALUES (?, ?, ?, ?, ?, ?)";
	            PreparedStatement custPs = conn.prepareStatement(insertCustomerSql);
	            custPs.setInt(1, loan.getCustomer().getCustomerId());
	            custPs.setString(2, loan.getCustomer().getName());
	            custPs.setString(3, loan.getCustomer().getEmail());
	            custPs.setString(4, loan.getCustomer().getPhone());
	            custPs.setString(5, loan.getCustomer().getAddress());
	            custPs.setInt(6, loan.getCustomer().getCreditScore());
	            custPs.executeUpdate();
	            System.out.println("New customer inserted.");
	        }

	        //Insert into Loan table
	        String sql = "INSERT INTO Loan (loanId, customerId, principalAmount, interestRate, loanTerm, loanType, loanStatus) VALUES (?, ?, ?, ?, ?, ?, ?)";
	        PreparedStatement ps = conn.prepareStatement(sql);
	        ps.setInt(1, loan.getLoanId());
	        ps.setInt(2, loan.getCustomer().getCustomerId());
	        ps.setDouble(3, loan.getPrincipalAmount());
	        ps.setDouble(4, loan.getInerestRate());
	        ps.setInt(5, loan.getLongTerm());
	        ps.setString(6, loan.getLoanType());
	        ps.setString(7, "Pending");
	        ps.executeUpdate();

	        // Insert type-specific loan details
	        if (loan instanceof HomeLoan) {
	            HomeLoan hl = (HomeLoan) loan;
	            String hsql = "INSERT INTO HomeLoan (loanId, propertyAddress, propertyValue) VALUES (?, ?, ?)";
	            PreparedStatement hps = conn.prepareStatement(hsql);
	            hps.setInt(1, hl.getLoanId());
	            hps.setString(2, hl.getPropertyAddress());
	            hps.setInt(3, hl.getPropertyValue());
	            hps.executeUpdate();
	        } 
	        else if (loan instanceof CarLoan) {
	            CarLoan cl = (CarLoan) loan;
	            String csql = "INSERT INTO CarLoan (loanId, carModel, carValue) VALUES (?, ?, ?)";
	            PreparedStatement cps = conn.prepareStatement(csql);
	            cps.setInt(1, cl.getLoanId());
	            cps.setString(2, cl.getCarModel());
	            cps.setInt(3, cl.getCarValue());
	            cps.executeUpdate();
	        }

	        System.out.println("Loan applied successfully with Pending status.");
	    } catch (SQLException e) {
	        System.out.println("Error applying loan: " + e.getMessage());
	        e.printStackTrace();
	    }
	}
	
	@Override
	public double calculateInterest(int loanId) {
		// TODO Auto-generated method stub
		try {
            Loan loan = getLoanById(loanId);
            return calculateInterest(loan.getPrincipalAmount(), loan.getInerestRate(), loan.getLongTerm());
        } 
		catch (InvalidLoanException e) {
            System.out.println("Error: "+e.getMessage());
            throw e;
        }
	}
	
	@Override
	public double calculateInterest(double principalAmount, double interesttRate, int loanTerm) {
		// TODO Auto-generated method stub
		return (principalAmount * interesttRate * loanTerm) / 1200;
	}
	
	@Override
	public void loanStatus(int loanId) {
		// TODO Auto-generated method stub
		try {
			Loan loan=getLoanById(loanId);
			int score=loan.getCustomer().getCreditScore();
			String status=(score>650) ? "Approved" : "Rejected";
			
			String sql="UPDATE Loan SET loanStatus=? WHERE loanId=?";
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, status);
			ps.setInt(2, loanId);
			ps.executeUpdate();
			
			System.out.println("Loan "+status);
		}
		catch(SQLException e) {
			throw new InvalidLoanException("Error updating loan status: "+e.getMessage());
		}
		
	}
	
	@Override
	public double calculateEMI(int loanId) {
		// TODO Auto-generated method stub
		try {
			Loan loan=getLoanById(loanId);
			 return calculateEMI(loan.getPrincipalAmount(), loan.getInerestRate(), loan.getLongTerm());
		}
		catch (InvalidLoanException e) {
            System.out.println(e.getMessage());
            throw e;
        }
	}
	
	@Override
	public double calculateEMI(double principalAmount, double annualRate, int loanTerm) {
		// TODO Auto-generated method stub
		 double r = annualRate / 12 / 100;
	        return (principalAmount * r * Math.pow(1 + r, loanTerm)) / (Math.pow(1 + r, loanTerm) - 1);
	}
	
	@Override
	public void loanRepayment(int loanId, double amount) {
		// TODO Auto-generated method stub
		try {
            double emi = calculateEMI(loanId);
            if (amount < emi) {
                System.out.println("Payment rejected. Amount is less than one EMI.");
                return;
            }
            int paidEmiCount = (int)(amount / emi);
            System.out.println("Payment accepted. You have paid " + paidEmiCount + " EMIs.");
        } 
		catch (InvalidLoanException e) {
            System.out.println(e.getMessage());
        }
		
	}
	
	@Override
	public List<Loan> getAllLoan() {
		// TODO Auto-generated method stub
		List<Loan> loanList=new ArrayList<>();
		try {
			String sql="SELECT loanId FROM Loan";
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				int id=rs.getInt("loanId");
				loanList.add(getLoanById(id));
			}
		}
		catch(SQLException e) {
			throw new InvalidLoanException("error fetching loans: "+e.getMessage());
		}
		return loanList;
	}
	
	@Override
	public Loan getLoanById(int loanId) {
		// TODO Auto-generated method stub
		try {
			String sql = "SELECT * FROM Loan l JOIN Customer c ON l.customerId = c.customerId WHERE l.loanId = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, loanId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                Customer cust = new Customer(
                        rs.getInt("customerId"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address"),
                        rs.getInt("creditScore")
                );

                String type = rs.getString("loanType");
                if (type.equals("HomeLoan")) {
                    PreparedStatement hps = conn.prepareStatement("SELECT * FROM HomeLoan WHERE loanId = ?");
                    hps.setInt(1, loanId);
                    ResultSet hrs = hps.executeQuery();
                    if (hrs.next()) {
                        return new HomeLoan(
                                loanId, cust,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                rs.getString("loanStatus"),
                                hrs.getString("propertyAddress"),
                                hrs.getInt("propertyValue"), type
                        );
                    }
                } 
                else if (type.equals("CarLoan")) {
                    PreparedStatement cps = conn.prepareStatement("SELECT * FROM CarLoan WHERE loanId = ?");
                    cps.setInt(1, loanId);
                    ResultSet crs = cps.executeQuery();
                    if (crs.next()) {
                        return new CarLoan(
                                loanId, cust,
                                rs.getDouble("principalAmount"),
                                rs.getDouble("interestRate"),
                                rs.getInt("loanTerm"),
                                rs.getString("loanStatus"),
                                crs.getString("carModel"),
                                crs.getInt("carValue"), type
                        );
                    }
                }
            }
        } 
		catch (SQLException e) {
            System.out.println("Error fetching loan: " + e.getMessage());
        }

        throw new InvalidLoanException("Loan with ID " + loanId + " not found.");
    }
}
package com.loan.dao;

import com.loan.entity.Loan;
import java.util.List;

public interface ILoanRepository {
	//Apply Loan
	void applyLoan(Loan loan);
	
	//Calculate interest by loanId
	double calculateInterest(int loanId);
	
	//Calculate interest using direct values
	double calculateInterest(double principalAmount, double interesttRate, int loanTerm);
	
	//Approve or reject loan
	void loanStatus(int loanId);
	
	//Calculate EMI by LoanId
	double calculateEMI(int loanId);
	
	//Calculate EMI using direct values
	double calculateEMI(double principalAmount, double annualRate, int loanTerm);
	
	//Loan Repayment
	void loanRepayment(int loanId, double amount);
	
	//Get all loans
	List<Loan> getAllLoan();
	
	//Get loan by Id
	Loan getLoanById(int loanId);

	
}

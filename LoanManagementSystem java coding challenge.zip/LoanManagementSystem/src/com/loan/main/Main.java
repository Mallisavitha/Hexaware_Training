package com.loan.main;

import com.loan.dao.*;
import com.loan.entity.*;
import com.loan.util.DatabaseConnection;

import java.sql.Connection;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String args[]) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            Scanner sc = new Scanner(System.in);
            ILoanRepository repo = new LoanRepositoryImpl(conn);

            while (true) {
                System.out.println("\n===== Loan Management Menu =====");
                System.out.println("1. Apply Loan");
                System.out.println("2. View All Loans");
                System.out.println("3. View Loan by ID");
                System.out.println("4. Repay Loan");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter Loan ID: ");
                        int loanId = sc.nextInt();

                        System.out.print("Enter Customer ID: ");
                        int customerId = sc.nextInt();
                        sc.nextLine();

                        System.out.print("Enter Customer Name: ");
                        String name = sc.nextLine();

                        System.out.print("Enter Email: ");
                        String email = sc.nextLine();

                        System.out.print("Enter Phone: ");
                        String phone = sc.nextLine();

                        System.out.print("Enter Address: ");
                        String address = sc.nextLine();

                        System.out.print("Enter Credit Score: ");
                        int score = sc.nextInt();
                        sc.nextLine(); 

                        Customer customer = new Customer(customerId, name, email, phone, address, score);

                        System.out.print("Enter Principal Amount: ");
                        double amount = sc.nextDouble();

                        System.out.print("Enter Interest Rate: ");
                        double rate = sc.nextDouble();

                        System.out.print("Enter Loan Term (in months): ");
                        int term = sc.nextInt();
                        sc.nextLine(); // Flush

                        System.out.print("Enter Loan Type (HomeLoan/CarLoan): ");
                        String type = sc.nextLine().trim();

                        if (type.equalsIgnoreCase("HomeLoan")) {
                            System.out.print("Enter Property Address: ");
                            String propAddr = sc.nextLine().trim();

                            System.out.print("Enter Property Value: ");
                            int propVal = sc.nextInt();
                            sc.nextLine();

                            HomeLoan hl = new HomeLoan(loanId, customer, amount, rate, term, "Pending", propAddr, propVal, type);
                            repo.applyLoan(hl);
                        } 
                        else if (type.equalsIgnoreCase("CarLoan")) {
                            System.out.print("Enter Car Model: ");
                            String carModel = sc.nextLine().trim();

                            System.out.print("Enter Car Value: ");
                            int carVal = sc.nextInt();
                            sc.nextLine();

                            CarLoan cl = new CarLoan(loanId, customer, amount, rate, term, "Pending", carModel, carVal, type);
                            repo.applyLoan(cl);
                        } 
                        else {
                            System.out.println("Invalid loan type.");
                        }
                        break;

                    case 2:
                        List<Loan> loans = repo.getAllLoan();
                        for (Loan l : loans) {
                            System.out.println(l);
                        }
                        break;

                    case 3:
                        System.out.print("Enter Loan ID to view: ");
                        int searchId = sc.nextInt();
                        Loan foundLoan = repo.getLoanById(searchId);
                        System.out.println(foundLoan);
                        break;

                    case 4:
                        System.out.print("Enter Loan ID for repayment: ");
                        int repayId = sc.nextInt();

                        System.out.print("Enter amount to repay: ");
                        double repayAmount = sc.nextDouble();
                        repo.loanRepayment(repayId, repayAmount);
                        break;

                    case 5:
                        System.out.println("Exiting Loan Management System. Goodbye!");
                        sc.close();
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }
            }

        } catch (Exception e) {
            System.out.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
